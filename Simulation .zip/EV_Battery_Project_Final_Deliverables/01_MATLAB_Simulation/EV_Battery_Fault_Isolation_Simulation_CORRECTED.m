%% EV Battery Fault Isolation and Spare-Module Reconfiguration
% Corrected reduced-order SYSTEM-LEVEL illustration.
% Not an electrochemical model, validated Simscape circuit, or hardware test.
% Faults are injected in software only. Do not reproduce faults on real cells.

clear; clc; close all;

%% Configuration
Nmain = 10; Nspare = 3; N = Nmain + Nspare;
dt = 0.1; tEnd = 80; t = (0:dt:tEnd)'; K = numel(t);
Vnom = 3.7; Rint = 0.045; Rload = 3.0; Tamb = 25;
Ttrip = 60; Vlow = 3.10; dTtrip = 1.0; Vmatch = 0.25;
faultModule = 6; faultStart = 15; faultKind = "combined"; % "thermal", "voltage", "combined", "none"
faultSag = 0.85; faultHeatRate = 1.5; thermalTau = 22;
TdetectDelay = 0.2; TisolateDelay = 0.2; TinsertDelay = 0.4;

% Main and spare module open-circuit voltages. Set spare values here for
% compatibility tests. Fault injection only affects the selected main module.
Voc = Vnom * ones(N,K);
Temp = Tamb * ones(N,K);

%% Signals and controller state
packV = zeros(K,1); packI = zeros(K,1); branchI = zeros(K,1);
detected = false(K,1); isolationCommand = false(K,1);
isoVerified = false(K,1); spareInserted = false(K,1);
reconVerified = false(K,1); shutdown = false(K,1);
state = zeros(K,1); % 0 monitor, 1 detected, 2 isolate, 3 verify isolation, 4 insert spare, 5 verify reconfig, 6 shutdown
events = strings(K,1); events(:) = "Monitoring";
active = 1:Nmain; chosenSpare = 0;
tDetect = NaN; tIsoCmd = NaN; tIsoVerified = NaN; tInsert = NaN;
latched = false; isolated = false; inserted = false; isShutdown = false;

% Independent isolation verification uses a simulated leakage/current sensor
% reading after the switch command; it is not hard-wired to the command flag.
leakageCurrentAfterOpen = 0.02; isolationCurrentLimit = 0.15;

for k = 2:K
    tk = t(k);
    prevActive = active;

    % Reduced-order thermal model for all modules.
    % Approximate previous-step current using current topology.
    nActive = max(numel(prevActive),1);
    prevVocSum = sum(Voc(prevActive,k-1));
    Iprev = max(0, prevVocSum / (Rload + Rint*nActive));
    for m = 1:N
        if ismember(m,prevActive)
            Temp(m,k) = Temp(m,k-1) + dt*((Tamb-Temp(m,k-1))/thermalTau + 0.08*Iprev^2);
        else
            Temp(m,k) = Temp(m,k-1) + dt*(Tamb-Temp(m,k-1))/thermalTau;
        end
        Voc(m,k) = Voc(m,k-1);
    end

    % Software-only fault injection while the fault branch remains connected.
    if tk >= faultStart && ~isolated && faultKind ~= "none"
        if faultKind == "thermal" || faultKind == "combined"
            Temp(faultModule,k) = Temp(faultModule,k-1) + faultHeatRate*dt;
        end
        if faultKind == "voltage" || faultKind == "combined"
            Voc(faultModule,k) = max(0.5,Vnom-faultSag);
        end
    end

    % Calculate pre-switch current consistently from series-module equivalent.
    if ~isShutdown && ~isempty(active)
        n = numel(active);
        moduleVoc = Voc(active,k);
        I = max(0, sum(moduleVoc)/(Rload + Rint*n));
        moduleTermV = moduleVoc - I*Rint;
        packI(k) = I;
        packV(k) = sum(moduleTermV);
    else
        packI(k) = 0; packV(k) = 0;
    end

    dT = (Temp(faultModule,k)-Temp(faultModule,k-1))/dt;
    trigger = tk >= faultStart && faultKind ~= "none" && ...
        (Voc(faultModule,k) < Vlow || Temp(faultModule,k) >= Ttrip || dT >= dTtrip);

    % State machine with explicit delays and verification gates.
    if ~latched && trigger
        latched = true; tDetect = tk; state(k) = 1;
        detected(k) = true; events(k) = "FAULT DETECTED: M" + string(faultModule);
    end
    if latched, detected(k) = true; end

    if latched && isnan(tIsoCmd) && tk >= tDetect + TdetectDelay
        tIsoCmd = tk; isolationCommand(k) = true; state(k) = 2;
        events(k) = "Isolation command issued for M" + string(faultModule);
    end
    if ~isnan(tIsoCmd) && isnan(tIsoVerified) && tk >= tIsoCmd + TisolateDelay
        % Remove faulty module from active path, then verify a separately
        % modelled residual/leakage-current reading against the threshold.
        active(active == faultModule) = [];
        isolated = true; tIsoVerified = tk;
        branchI(k) = leakageCurrentAfterOpen;
        isoVerified(k) = branchI(k) < isolationCurrentLimit;
        state(k) = 3;
        if isoVerified(k)
            events(k) = "Isolation verified for M" + string(faultModule);
        else
            isShutdown = true; shutdown(k) = true; state(k) = 6;
            events(k) = "Isolation verification failed: safe shutdown";
        end
    end

    if isolated && isoVerified(k) && ~inserted && ~isShutdown && tk >= tIsoVerified + TinsertDelay
        % Match spares to nominal bus/module voltage requirement, not to the
        % faulty module's depressed voltage. This remains a simplified check.
        candidates = (Nmain+1):N;
        spareVoltage = Voc(candidates,k);
        eligible = candidates(abs(spareVoltage - Vnom) <= Vmatch);
        if isempty(eligible)
            isShutdown = true; shutdown(k) = true; state(k) = 6;
            events(k) = "No compatible spare: safe shutdown";
        else
            chosenSpare = eligible(1); active = [active chosenSpare];
            inserted = true; tInsert = tk; spareInserted(k) = true;
            state(k) = 4; events(k) = "Spare M" + string(chosenSpare) + " inserted";
        end
    end

    if inserted && ~isShutdown
        % Recompute output after topology change using a consistent equivalent
        % series model. Verify count restored to Nmain and finite positive output.
        n = numel(active);
        Ipost = max(0, sum(Voc(active,k))/(Rload + Rint*n));
        Vpost = sum(Voc(active,k) - Ipost*Rint);
        packI(k) = Ipost; packV(k) = Vpost;
        reconOK = (n == Nmain) && isfinite(Vpost) && isfinite(Ipost) && Vpost > 0 && Ipost > 0;
        if reconOK
            reconVerified(k) = true; state(k) = 5;
            if events(k) == "Monitoring" || events(k) == "Spare M" + string(chosenSpare) + " inserted"
                events(k) = "Reconfiguration verified with spare M" + string(chosenSpare);
            end
        else
            isShutdown = true; shutdown(k) = true; state(k) = 6;
            events(k) = "Reconfiguration verification failed: safe shutdown";
        end
    end

    % Branch current: before isolation it carries pack current; after opening,
    % it is the modelled leakage-current sensor reading.
    if ~isolated
        branchI(k) = packI(k);
    elseif isnan(tIsoVerified)
        branchI(k) = packI(k);
    else
        branchI(k) = leakageCurrentAfterOpen;
    end

    if isShutdown
        shutdown(k) = true; packI(k) = 0; packV(k) = 0; state(k) = 6;
    end
    if latched, detected(k) = true; end
    if isolated, isolationCommand(k) = true; end
    if inserted, spareInserted(k) = true; end
    if ~isnan(tIsoVerified) && isoVerified(max(k-1,1)), isoVerified(k) = true; end
    if inserted && reconVerified(max(k-1,1)) && ~isShutdown, reconVerified(k) = true; end
    if isShutdown, shutdown(k) = true; end
    if events(k) == "Monitoring" && state(k) == 0, events(k) = "Monitoring"; end
end

% Hold state flags from their transition onward for plotting.
for k = 2:K
    detected(k) = detected(k) || detected(k-1);
    isolationCommand(k) = isolationCommand(k) || isolationCommand(k-1);
    isoVerified(k) = isoVerified(k) || isoVerified(k-1);
    spareInserted(k) = spareInserted(k) || spareInserted(k-1);
    reconVerified(k) = reconVerified(k) || reconVerified(k-1);
    shutdown(k) = shutdown(k) || shutdown(k-1);
    if state(k) == 0 && state(k-1) ~= 0, state(k) = state(k-1); end
end

%% Plots
figure('Name','EV Battery Fault Isolation - Corrected System-Level Model','Color','w','Position',[60 60 1250 850]);
tiledlayout(3,2,'TileSpacing','compact','Padding','compact');
nexttile; plot(t,Temp(1:Nmain,:)','LineWidth',1); hold on; yline(Ttrip,'r--','Trip'); xline(faultStart,'k:');
title('Main-module temperature'); xlabel('Time (s)'); ylabel('Temperature (°C)'); grid on; legend(compose('M%d',1:Nmain),'Location','eastoutside');
nexttile; plot(t,Voc(1:Nmain,:)','LineWidth',1); hold on; yline(Vlow,'r--','Low voltage'); xline(faultStart,'k:');
title('Main-module open-circuit voltage proxy'); xlabel('Time (s)'); ylabel('Voltage (V)'); grid on;
nexttile; plot(t,packV,'LineWidth',1.7); hold on; yline(Nmain*Vnom,'k--','Nominal open-circuit reference'); xline(faultStart,'k:');
title('Pack terminal voltage'); xlabel('Time (s)'); ylabel('Voltage (V)'); grid on;
nexttile; plot(t,packI,'LineWidth',1.7); hold on; plot(t,branchI,'--','LineWidth',1.3);
title('Pack and fault-branch current'); xlabel('Time (s)'); ylabel('Current (A)'); legend('Pack current','Fault branch'); grid on;
nexttile; stairs(t,double(detected),'LineWidth',1.4); hold on; stairs(t,double(isolationCommand),'LineWidth',1.4);
stairs(t,double(isoVerified),'--','LineWidth',1.2); stairs(t,double(spareInserted),'LineWidth',1.4); stairs(t,double(reconVerified),'-.','LineWidth',1.2);
title('Detection, isolation and reconfiguration'); xlabel('Time (s)'); ylabel('Logic'); ylim([-0.1 1.1]); grid on;
legend('Fault detected','Isolation command','Isolation verified','Spare inserted','Reconfiguration verified','Location','best');
nexttile; stairs(t,state,'LineWidth',1.7); title('Controller state (0 monitor, 1 detect, 2 isolate command, 3 verify isolation, 4 insert spare, 5 verified, 6 shutdown)');
xlabel('Time (s)'); ylabel('State'); yticks(0:6); ylim([-0.2 6.2]); grid on;
sgtitle(sprintf('10 Main + 3 Spare Modules | M%d | %s fault',faultModule,faultKind));

%% Console report
fprintf('\nILLUSTRATIVE SYSTEM-LEVEL SIMULATION — NOT HARDWARE MEASUREMENTS\n');
fprintf('Fault module: M%d | type: %s | fault start: %.2f s\n',faultModule,faultKind,faultStart);
if ~isnan(tDetect), fprintf('Fault detection time: %.2f s (latency %.2f s)\n',tDetect,tDetect-faultStart); else, fprintf('Fault not detected.\n'); end
if ~isnan(tIsoCmd), fprintf('Isolation command time: %.2f s\n',tIsoCmd); else, fprintf('Isolation command: not issued.\n'); end
if ~isnan(tIsoVerified), fprintf('Isolation verification time: %.2f s | result: %d\n',tIsoVerified,isoVerified(end)); else, fprintf('Isolation verification: not completed.\n'); end
if inserted, fprintf('Spare inserted: M%d at %.2f s\n',chosenSpare,tInsert); else, fprintf('Spare inserted: NO\n'); end
fprintf('Final pack voltage: %.2f V | final current: %.2f A\n',packV(end),packI(end));
fprintf('Reconfiguration verified: %d | safe shutdown: %d\n',reconVerified(end),shutdown(end));
ev = find(events ~= "Monitoring");
if ~isempty(ev), disp(table(t(ev),events(ev),'VariableNames',{'Time_s','Event'})); end

results = table(t,packV,packI,Temp(faultModule,:)',Voc(faultModule,:)',double(detected), ...
    double(isolationCommand),double(isoVerified),double(spareInserted),double(reconVerified),double(shutdown),state, ...
    'VariableNames',{'Time_s','PackVoltage_V','PackCurrent_A','FaultModuleTemperature_C','FaultModuleVoltageProxy_V', ...
    'FaultDetected','IsolationCommand','IsolationVerified','SpareInserted','ReconfigurationVerified','SafeShutdown','ControllerState'});
writetable(results,'EV_Battery_Corrected_Results.csv');
save('EV_Battery_Corrected_Workspace.mat');
disp('Saved EV_Battery_Corrected_Results.csv and EV_Battery_Corrected_Workspace.mat');

% Limits: reduced-order model; not electrochemical, thermal runaway, detailed
% contactor/precharge, SOC/impedance, or Simscape circuit simulation. The
% isolation-current value is a simulated sensor assumption, not circuit-derived.
% Fault detection remains threshold-based; no machine-learning AI is implemented.
