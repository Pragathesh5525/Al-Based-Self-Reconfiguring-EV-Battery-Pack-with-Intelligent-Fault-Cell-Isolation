%% EV_Battery_Test_07_Regression_Audit.m
% Test 07: audit the saved outputs from Tests 01-06.
% This script DOES NOT rerun simulations and DOES NOT validate hardware.
% Run it from the folder containing the six EV_Battery_Test_0*_Results.csv files.

clear; clc;

files = [ ...
    "EV_Battery_Test_01_Healthy_Results.csv"; ...
    "EV_Battery_Test_02_Voltage_Fault_Results.csv"; ...
    "EV_Battery_Test_03_Combined_Fault_Results.csv"; ...
    "EV_Battery_Test_04_Isolation_Failure_Results.csv"; ...
    "EV_Battery_Test_05_No_Compatible_Spare_Results.csv"; ...
    "EV_Battery_Test_06_Thermal_Shutdown_Results.csv" ];
labels = ["Healthy baseline"; "Voltage fault"; "Combined fault"; ...
          "Isolation verification failure"; "No compatible spare"; "Thermal shutdown"];

required = ["Time_s","PackVoltage_V","PackCurrent_A","FaultDetected", ...
    "IsolationCommand","IsolationVerified","SpareInserted", ...
    "ReconfigurationVerified","Shutdown"];
Rload = 3.0; tolVI = 1e-3; zeroTol = 1e-6;
results = strings(numel(files),1);

fprintf('\nEV BATTERY TEST 07 - SAVED-OUTPUT REGRESSION AUDIT\n');
fprintf('This checks CSV consistency only; it is not hardware validation.\n\n');

for i = 1:numel(files)
    fprintf('Test %02d: %s\n',i,labels(i));
    if ~isfile(files(i))
        results(i) = "FAIL - missing CSV: " + files(i);
        fprintf('  FAIL: file not found: %s\n\n',files(i));
        continue
    end
    try
        T = readtable(files(i));
    catch ME
        results(i) = "FAIL - CSV read error";
        fprintf('  FAIL: could not read CSV: %s\n\n',ME.message);
        continue
    end
    vars = string(T.Properties.VariableNames);
    missing = required(~ismember(required,vars));
    if ~isempty(missing)
        results(i) = "FAIL - missing columns: " + strjoin(missing,", ");
        fprintf('  FAIL: missing columns: %s\n\n',strjoin(missing,', '));
        continue
    end

    t = double(T.Time_s(:)); V = double(T.PackVoltage_V(:)); I = double(T.PackCurrent_A(:));
    finiteOK = all(isfinite(t)) && all(isfinite(V)) && all(isfinite(I));
    orderedOK = numel(t) >= 2 && all(diff(t) > 0);
    viOK = finiteOK && max(abs(V-I*Rload)) <= tolVI;
    det = logical(T.FaultDetected(:)); isoCmd = logical(T.IsolationCommand(:));
    isoOK = logical(T.IsolationVerified(:)); spare = logical(T.SpareInserted(:));
    recon = logical(T.ReconfigurationVerified(:)); shut = logical(T.Shutdown(:));
    noFault = ~any(det) && ~any(isoCmd) && ~any(shut);
    eventOrderOK = true;
    if any(isoCmd), eventOrderOK = eventOrderOK && any(det) && find(det,1,'first') <= find(isoCmd,1,'first'); end
    if any(isoOK), eventOrderOK = eventOrderOK && any(isoCmd) && find(isoCmd,1,'first') <= find(isoOK,1,'first'); end
    if any(spare), eventOrderOK = eventOrderOK && any(isoOK) && find(isoOK,1,'first') <= find(spare,1,'first'); end
    if any(recon), eventOrderOK = eventOrderOK && any(spare) && find(spare,1,'first') <= find(recon,1,'first'); end

    scenarioOK = finiteOK && orderedOK && viOK && eventOrderOK;
    if i == 1
        scenarioOK = scenarioOK && noFault;
    else
        scenarioOK = scenarioOK && any(det);
    end
    if i == 4 || i == 5 || i == 6
        scenarioOK = scenarioOK && any(shut) && abs(V(end)) <= zeroTol && abs(I(end)) <= zeroTol;
    end
    if i == 2
        % Voltage-fault case should recover/reconfigure without shutdown.
        scenarioOK = scenarioOK && any(isoOK) && any(spare) && any(recon) && ~any(shut) && V(end) > 0 && I(end) > 0;
    end
    if i == 3
        % Combined-fault case may shut down if thermal threshold is reached.
        scenarioOK = scenarioOK && any(isoCmd);
    end

    if scenarioOK, results(i) = "PASS - saved-output checks"; else, results(i) = "REVIEW - one or more checks failed"; end
    fprintf('  Rows: %d | final V: %.3f V | final I: %.3f A | shutdown: %d\n',height(T),V(end),I(end),any(shut));
    fprintf('  Finite: %d | time ordered: %d | V=I*Rload: %d | event order: %d\n',finiteOK,orderedOK,viOK,eventOrderOK);
    fprintf('  Result: %s\n\n',results(i));
end

AuditSummary = table((1:numel(files))',labels,files,results, ...
    'VariableNames',{'TestNumber','Scenario','CSVFile','AuditResult'});
writetable(AuditSummary,'EV_Battery_Test_07_Regression_Audit_Summary.csv');
disp(AuditSummary);
fprintf('\nSaved: EV_Battery_Test_07_Regression_Audit_Summary.csv\n');
fprintf('IMPORTANT: a PASS means only these programmed CSV checks passed; it is not proof of physical battery safety or hardware validation.\n');
