%% EV_Battery_Test_08_Results_Summary.m
% Test 08: summarize the saved results from Tests 01-06.
% This script does not rerun the simulations or validate hardware.
% Run from the folder containing the six EV_Battery_Test_0*_Results.csv files.

clear; clc;
files = [ ...
    "EV_Battery_Test_01_Healthy_Results.csv"; ...
    "EV_Battery_Test_02_Voltage_Fault_Results.csv"; ...
    "EV_Battery_Test_03_Combined_Fault_Results.csv"; ...
    "EV_Battery_Test_04_Isolation_Failure_Results.csv"; ...
    "EV_Battery_Test_05_No_Compatible_Spare_Results.csv"; ...
    "EV_Battery_Test_06_Thermal_Shutdown_Results.csv" ];
labels = ["Healthy baseline"; "Voltage fault"; "Combined fault"; ...
          "Isolation verification failure"; "No compatible spare"; "Thermal shutdown"];

n = numel(files);
rows = zeros(n,1); finalV = nan(n,1); finalI = nan(n,1); peakTemp = nan(n,1);
firstDetect = nan(n,1); firstIsolation = nan(n,1); firstShutdown = nan(n,1);
status = strings(n,1);

fprintf('\nEV BATTERY TEST 08 - RESULTS SUMMARY\n');
fprintf('Reads existing CSV outputs only; no simulation is run.\n\n');
for k = 1:n
    if ~isfile(files(k))
        status(k) = "MISSING CSV";
        fprintf('Test %02d: missing %s\n',k,files(k));
        continue
    end
    try
        T = readtable(files(k));
        vars = string(T.Properties.VariableNames);
        required = ["Time_s","PackVoltage_V","PackCurrent_A"];
        if ~all(ismember(required,vars))
            status(k) = "MISSING REQUIRED COLUMNS";
            fprintf('Test %02d: required columns missing in %s\n',k,files(k));
            continue
        end
        rows(k) = height(T); finalV(k) = T.PackVoltage_V(end); finalI(k) = T.PackCurrent_A(end);
        if ismember("FaultTemp_C",vars), peakTemp(k) = max(T.FaultTemp_C,[],'omitnan'); end
        if ismember("FaultDetected",vars), idx=find(T.FaultDetected~=0,1); if ~isempty(idx), firstDetect(k)=T.Time_s(idx); end, end
        if ismember("IsolationCommand",vars), idx=find(T.IsolationCommand~=0,1); if ~isempty(idx), firstIsolation(k)=T.Time_s(idx); end, end
        if ismember("Shutdown",vars), idx=find(T.Shutdown~=0,1); if ~isempty(idx), firstShutdown(k)=T.Time_s(idx); end, end
        status(k) = "READ OK - review scenario criteria separately";
        fprintf('Test %02d %-32s rows=%d finalV=%.3f V finalI=%.3f A peakTemp=%.2f C\n', ...
            k,labels(k),rows(k),finalV(k),finalI(k),peakTemp(k));
    catch ME
        status(k) = "READ ERROR: " + string(ME.message);
        fprintf('Test %02d: read error: %s\n',k,ME.message);
    end
end
Summary = table((1:n)',labels,files,rows,finalV,finalI,peakTemp,firstDetect,firstIsolation,firstShutdown,status, ...
    'VariableNames',{'TestNumber','Scenario','CSVFile','Rows','FinalPackVoltage_V','FinalPackCurrent_A','PeakFaultTemperature_C','FirstDetection_s','FirstIsolationCommand_s','FirstShutdown_s','ReadStatus'});
writetable(Summary,'EV_Battery_Test_08_Results_Summary.csv');
disp(Summary);
fprintf('\nSaved EV_Battery_Test_08_Results_Summary.csv\n');
fprintf('Note: this is a data summary, not proof of physical safety or hardware validation.\n');
