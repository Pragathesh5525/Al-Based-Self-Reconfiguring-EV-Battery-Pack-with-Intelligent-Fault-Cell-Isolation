%% Run_EV_Battery_Model_Tests.m
% Builds and tests the signal-level EV battery reconfiguration model.
% Requires MATLAB + Simulink. This does not validate a physical battery circuit.

clear; clc;
thisDir = fileparts(mfilename('fullpath'));
if isempty(thisDir), thisDir = pwd; end
addpath(thisDir);
run(fullfile(thisDir,'Build_EV_Battery_Functional_Simulink_Model_FIXED.m'));
model = 'EV_Battery_Functional_Simulink_Model';
set_param(model,'StopTime','80');
set_param(model,'ReturnWorkspaceOutputs','on');

fprintf('\nTEST A: fault with compatible spare\n');
set_param([model '/Spare_Compatible'],'Value','1');
outA = sim(model);
va = outA.get('pack_voltage_log');
fa = outA.get('fault_status_log');
sa = outA.get('shutdown_status_log');
ta = outA.get('m5_temperature_log');
assert(~isempty(va) && ~isempty(fa) && ~isempty(sa), 'Missing logged signals.');
assert(any(fa.Data(:) > 0.5), 'FAIL: fault was not detected.');
assert(abs(va.Data(end) - 37) < 1e-3, 'FAIL: expected recovered pack voltage near 37 V.');
assert(sa.Data(end) < 0.5, 'FAIL: unexpected shutdown with compatible spare.');
assert(abs(max(ta.Data(:)) - 56.3) < 1e-2, 'FAIL: expected temperature profile not observed.');
fprintf('PASS: fault detected, compatible spare recovery reached 37 V, no shutdown.\n');

fprintf('\nTEST B: fault with no compatible spare\n');
set_param([model '/Spare_Compatible'],'Value','0');
outB = sim(model);
vb = outB.get('pack_voltage_log');
fb = outB.get('fault_status_log');
sb = outB.get('shutdown_status_log');
assert(any(fb.Data(:) > 0.5), 'FAIL: fault was not detected in Test B.');
assert(sb.Data(end) > 0.5, 'FAIL: expected shutdown without compatible spare.');
assert(abs(vb.Data(end)) < 1e-3, 'FAIL: expected zero output voltage after shutdown.');
fprintf('PASS: no compatible spare caused safe shutdown and zero output.\n');

fprintf('\nALL MODEL-LEVEL CHECKS PASSED.\n');
fprintf('These checks verify this simplified signal-level model only, not Simscape physics or hardware.\n');
