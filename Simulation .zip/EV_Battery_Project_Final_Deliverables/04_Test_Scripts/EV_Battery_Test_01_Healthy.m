%% EV_Battery_Research_Model_FINAL_REVIEWED_v2.m
% Reduced-order system-level simulation for a 10-main + 3-spare EV battery pack.
% SOFTWARE MODEL ONLY: not an electrochemical cell model and not hardware validated.
% Faults and isolation-current readings are simulated; do not fault-inject real cells.
% Revision v3: preserves residual thermal-fault heating after electrical isolation
% and invokes a latched thermal safety shutdown if the module reaches Ttrip.

clear; clc; close all;

%% 1. Configuration
Nmain = 10; Nspare = 3; N = Nmain + Nspare;
dt = 0.05; tEnd = 80; t = (0:dt:tEnd)'; K = numel(t);
Vnom = 3.7; Rint = 0.045; Rload = 3.0; Tamb = 25;
Ttrip = 60; Vlow = 3.10; dTtrip = 1.0; Vmatch = 0.25;
thermalCurrentGain = 0.00012; % illustrative thermal coefficient; calibrate against measured data
thermalFaultPersistsAfterIsolation = true; % conservative software scenario, not cell-validated
faultModule = 6; faultStart = 15; faultKind = "none"; % thermal | voltage | combined | none
faultHeatRate = 1.5; faultVoltageDrop = 0.85;
detectDelay = 0.10; isolateDelay = 0.20; verifyDelay = 0.20;
sparePrepDelay = 0.50; insertionDelay = 0.20; reconVerifyDelay = 0.20;
spareVoc = [3.70 3.68 3.72];
% Independent, simulated isolation-current sensor model:
isolationCurrentLimit = 0.15; residualCurrentAfterOpen = 0.02;
% Set true ONLY to simulate an isolation-verification failure test:
forceIsolationVerificationFailure = false;

%% 2. Signals and controller state
Voc = Vnom*ones(N,K); Vterm = Vnom*ones(N,K); Temp = Tamb*ones(N,K);
packV = zeros(K,1); packI = zeros(K,1); faultBranchI = zeros(K,1);
faultDetected = false(K,1); isolationCmd = false(K,1); isoVerified = false(K,1);
spareSelected = zeros(K,1); spareInserted = false(K,1); reconVerified = false(K,1);
shutdown = false(K,1); faultInjected = false(K,1); state = zeros(K,1);
event = strings(K,1); event(:) = "Monitoring";
% Initialize the t=0 healthy operating point consistently with the series model.
active = 1:Nmain;
packI(1) = sum(Voc(active,1))/(Rload + Rint*numel(active));
Vterm(active,1) = max(0,Voc(active,1)-packI(1)*Rint);
packV(1) = sum(Vterm(active,1));
faultBranchI(1) = packI(1);
% State: 0 monitor, 1 detected, 2 isolation commanded, 3 isolated verified,
% 4 spare preparation, 5 spare inserted, 6 reconfiguration verified, 7 shutdown.
active = 1:Nmain; faultLatched = false; isolationCommanded = false;
stopFlag = false; isolationPass = false; chosenSpare = 0;
tDetect = NaN; tIso = NaN; tIsoV = NaN; tPrep = NaN; tInsert = NaN; tRecon = NaN;

%% 3. Discrete-time simulation
for k = 2:K
    tk = t(k);
    Voc(:,k) = Voc(:,k-1);
    Temp(:,k) = Temp(:,k-1);

    % Apply simulated fault disturbance before calculating electrical response.
    if tk >= faultStart && faultKind ~= "none" && ~isolationCommanded
        faultInjected(k) = true;
        % Normal thermal update for every module, then add the fault heat.
        for m = 1:N
            if ismember(m,active)
                dTemp = (Tamb-Temp(m,k-1))/22 + thermalCurrentGain*(packI(k-1)^2);
            else
                dTemp = (Tamb-Temp(m,k-1))/22;
            end
            Temp(m,k) = Temp(m,k-1) + dt*dTemp;
        end
        if faultKind == "thermal" || faultKind == "combined"
            % Persistent heating while the faulted module remains connected.
            Temp(faultModule,k) = Temp(faultModule,k) + faultHeatRate*dt;
        end
        if faultKind == "voltage" || faultKind == "combined"
            Voc(faultModule,k) = max(0.5,Vnom-faultVoltageDrop);
        end
    else
        % First-order cooling/Joule heating for normal connected modules.
        % The isolated faulted module cools unless persistent thermal-fault
        % heating is enabled for the conservative thermal-runaway scenario.
        for m = 1:N
            if ismember(m,active)
                dTemp = (Tamb-Temp(m,k-1))/22 + thermalCurrentGain*(packI(k-1)^2);
            else
                dTemp = (Tamb-Temp(m,k-1))/22;
            end
            Temp(m,k) = Temp(m,k-1) + dt*dTemp;
        end
        if thermalFaultPersistsAfterIsolation && isolationCommanded && ...
                (faultKind == "thermal" || faultKind == "combined")
            Temp(faultModule,k) = Temp(faultModule,k) + faultHeatRate*dt;
        end
    end

    % Compute electrical output from the same time-step values (series model).
    if isempty(active) || stopFlag
        packI(k) = 0; packV(k) = 0;
    else
        nActive = numel(active);
        packI(k) = max(0,sum(Voc(active,k))/(Rload + Rint*nActive));
        Vterm(:,k) = Voc(:,k);
        Vterm(active,k) = max(0,Voc(active,k)-packI(k)*Rint);
        packV(k) = sum(Vterm(active,k));
    end

    % Fault detection from low loaded module voltage, absolute temperature,
    % or temperature-rise rate. This is threshold/rule-based logic, not trained AI.
    dTdt = (Temp(faultModule,k)-Temp(faultModule,k-1))/dt;
    moduleLoadedVoltage = Voc(faultModule,k)-packI(k)*Rint;
    trigger = faultInjected(k) && (moduleLoadedVoltage < Vlow || ...
        Temp(faultModule,k) >= Ttrip || dTdt >= dTtrip);
    if trigger && ~faultLatched
        faultLatched = true;
        tDetect = tk + detectDelay;
        event(k) = "Fault trigger observed; detection pending";
    end

    if faultLatched && ~stopFlag
        % Record detection only when the configured detection delay has elapsed.
        if tk >= tDetect
            faultDetected(k) = true;
            if k == 2 || ~faultDetected(k-1)
                event(k) = "Fault detected at M" + faultModule;
            end
        end
        if isnan(tIso) && tk >= tDetect + isolateDelay
            tIso = tk; isolationCommanded = true; isolationCmd(k) = true;
            active(active == faultModule) = [];
            event(k) = "Isolation command: M" + faultModule;
        elseif ~isnan(tIso)
            isolationCmd(k) = true;
        end

        % Independent simulated sensor reading after the open command. It is
        % deliberately NOT inferred from membership in the active-module list.
        if ~isnan(tIso) && isnan(tIsoV) && tk >= tIso + verifyDelay
            tIsoV = tk;
            measuredResidualCurrent = residualCurrentAfterOpen;
            if forceIsolationVerificationFailure
                measuredResidualCurrent = max(0.50,isolationCurrentLimit + 0.01);
            end
            faultBranchI(k) = measuredResidualCurrent;
            if measuredResidualCurrent < isolationCurrentLimit
                isolationPass = true; isoVerified(k) = true; event(k) = "Isolation verified by simulated current sensor";
            else
                stopFlag = true; shutdown(k) = true; state(k) = 7;
                event(k) = "Isolation verification failed: safe shutdown";
            end
        elseif ~isnan(tIso) && ~isnan(tIsoV)
            if isolationPass, isoVerified(k) = true; end
            if forceIsolationVerificationFailure
                faultBranchI(k) = max(0.50,isolationCurrentLimit + 0.01);
            else
                faultBranchI(k) = residualCurrentAfterOpen;
            end
        elseif ~isolationCommanded
            faultBranchI(k) = packI(k);
        end

        if ~stopFlag && ~isnan(tIsoV) && isolationPass && chosenSpare == 0 && tk >= tIsoV + sparePrepDelay
            spareIdx = Nmain + (1:Nspare);
            healthyIdx = setdiff(active, faultModule);
            if isempty(healthyIdx), referenceVoltage = Vnom;
            else, referenceVoltage = median(Voc(healthyIdx,k)); end
            compatible = spareIdx(abs(spareVoc-referenceVoltage) <= Vmatch);
            if isempty(compatible)
                stopFlag = true; shutdown(k) = true; state(k) = 7;
                event(k) = "No voltage-compatible spare: safe shutdown";
            else
                chosenSpare = compatible(1); tPrep = tk;
                event(k) = "Spare M" + chosenSpare + " passed voltage check";
            end
        end

        if ~stopFlag && chosenSpare > 0 && isnan(tInsert) && tk >= tPrep + insertionDelay
            active = [active chosenSpare]; tInsert = tk;
            spareSelected(k) = chosenSpare; spareInserted(k) = true;
            event(k) = "Spare M" + chosenSpare + " inserted";
        elseif chosenSpare > 0 && ~isnan(tInsert)
            spareSelected(k) = chosenSpare; spareInserted(k) = true;
        end

        if ~stopFlag && ~isnan(tInsert) && isnan(tRecon) && tk >= tInsert + reconVerifyDelay
            tRecon = tk;
            % Verify topology and voltage/current relation for the reduced-order model.
            expectedCount = Nmain;
            nActive = numel(active);
            testI = max(0,sum(Voc(active,k))/(Rload+Rint*nActive));
            testV = sum(Voc(active,k))-testI*Rint*nActive;
            if nActive == expectedCount && testV > 0 && ...
                    abs(testV-testI*Rload) < 1e-8
                reconVerified(k) = true; event(k) = "Reconfiguration verification passed";
            else
                stopFlag = true; shutdown(k) = true; state(k) = 7;
                event(k) = "Reconfiguration verification failed: safe shutdown";
            end
        elseif ~isnan(tRecon) && ~stopFlag
            reconVerified(k) = true;
        end
    end

    % Independent thermal safety override: electrical isolation does not guarantee
    % that an already-heated/faulted module has stopped generating heat.
    if ~stopFlag && thermalFaultPersistsAfterIsolation && isolationCommanded && ...
            (faultKind == "thermal" || faultKind == "combined") && Temp(faultModule,k) >= Ttrip
        stopFlag = true; shutdown(k) = true; state(k) = 7;
        event(k) = "Post-isolation thermal limit reached: safe shutdown";
    end

    % Enforce persistent shutdown and consistent output after shutdown.
    if stopFlag
        shutdown(k) = true; packI(k) = 0; packV(k) = 0; state(k) = 7;
    else
        if ~isnan(tRecon), state(k) = 6;
        elseif ~isnan(tInsert), state(k) = 5;
        elseif chosenSpare > 0 && isnan(tInsert), state(k) = 4;
        elseif ~isnan(tIsoV) && isolationPass, state(k) = 3;
        elseif ~isnan(tIso), state(k) = 2;
        elseif faultLatched && tk >= tDetect, state(k) = 1;
        else, state(k) = 0; end
    end

    % Current through the faulty branch before opening follows pack current;
    % after opening it comes only from the independent simulated sensor model.
    if ~isolationCommanded
        faultBranchI(k) = packI(k);
    elseif isnan(tIsoV)
        faultBranchI(k) = residualCurrentAfterOpen;
    end
    if ~isempty(event(k)) && event(k) == "Monitoring" && k > 2
        event(k) = event(k-1);
    end
end

% Hold event flags and selected spare between transition instants.
for k = 2:K
    faultDetected(k) = faultDetected(k) || faultDetected(k-1);
    isolationCmd(k) = isolationCmd(k) || isolationCmd(k-1);
    isoVerified(k) = isoVerified(k) || isoVerified(k-1);
    spareInserted(k) = spareInserted(k) || spareInserted(k-1);
    reconVerified(k) = reconVerified(k) || reconVerified(k-1);
    shutdown(k) = shutdown(k) || shutdown(k-1);
    if spareSelected(k) == 0, spareSelected(k) = spareSelected(k-1); end
    if state(k) == 0, state(k) = state(k-1); end
end

%% 4. Paper-friendly figures
figure('Name','EV battery fault response - reduced-order model','Color','w','Position',[50 50 1350 850]);
tiledlayout(3,2,'TileSpacing','compact','Padding','compact');
nexttile; plot(t,Temp(1:Nmain,:)','LineWidth',1); hold on; yline(Ttrip,'r--','Trip'); xline(faultStart,'k:');
title('Main-module temperature'); xlabel('Time (s)'); ylabel('Temperature (°C)'); grid on;
legend(compose('M%d',1:Nmain),'Location','eastoutside');
nexttile; plot(t,Vterm(1:Nmain,:)','LineWidth',1); hold on; yline(Vlow,'r--','Low voltage'); xline(faultStart,'k:');
title('Main-module voltage proxy'); xlabel('Time (s)'); ylabel('Voltage (V)'); grid on;
legend(compose('M%d',1:Nmain),'Location','eastoutside');
nexttile; plot(t,packV,'LineWidth',1.5); hold on; xline(faultStart,'k:');
title('Pack terminal voltage'); xlabel('Time (s)'); ylabel('Voltage (V)'); grid on;
nexttile; plot(t,packI,'LineWidth',1.5); hold on; plot(t,faultBranchI,'--','LineWidth',1.2);
title('Pack and fault-branch current'); xlabel('Time (s)'); ylabel('Current (A)'); legend('Pack current','Fault branch current'); grid on;
nexttile; stairs(t,double(faultDetected),'LineWidth',1.2); hold on; stairs(t,double(isolationCmd),'LineWidth',1.2);
stairs(t,double(isoVerified),'--','LineWidth',1.2); stairs(t,double(spareInserted),'LineWidth',1.2); stairs(t,double(reconVerified),'-.','LineWidth',1.2);
title('Detection, isolation and reconfiguration'); xlabel('Time (s)'); ylabel('Logic'); ylim([-0.1 1.1]); grid on;
legend('Fault detected','Isolation command','Isolation verified','Spare inserted','Reconfiguration verified','Location','best');
nexttile; stairs(t,state,'LineWidth',1.5); title('Controller state'); xlabel('Time (s)'); ylabel('State');
yticks(0:7); yticklabels({'Monitor','Detected','Isolate','Iso verified','Prepare spare','Inserted','Verified','Shutdown'}); grid on;
sgtitle(sprintf('10 main + 3 spare modules | M%d | %s fault | illustrative model',faultModule,faultKind));

%% 5. Results export
results = table(t,packV,packI,Temp(faultModule,:)',Vterm(faultModule,:)',faultBranchI, ...
    double(faultDetected),double(isolationCmd),double(isoVerified),spareSelected, ...
    double(spareInserted),double(reconVerified),double(shutdown),state, ...
    'VariableNames',{'Time_s','PackVoltage_V','PackCurrent_A','FaultTemp_C','FaultModuleVoltage_V', ...
    'FaultBranchCurrent_A','FaultDetected','IsolationCommand','IsolationVerified','SelectedSpare', ...
    'SpareInserted','ReconfigurationVerified','Shutdown','ControllerState'});
writetable(results,'EV_Battery_Test_01_Healthy_Results.csv');
save('EV_Battery_Test_01_Healthy_Workspace.mat');

fprintf('\nREDUCED-ORDER SIMULATION — NOT HARDWARE VALIDATION\n');
fprintf('Fault: M%d | type: %s | injection time: %.2f s\n',faultModule,faultKind,faultStart);
idx = find(faultDetected,1); if ~isempty(idx), fprintf('Detection recorded at %.2f s\n',t(idx)); end
idx = find(isolationCmd,1); if ~isempty(idx), fprintf('Isolation command recorded at %.2f s\n',t(idx)); end
idx = find(isoVerified,1); if ~isempty(idx), fprintf('Isolation verification recorded at %.2f s\n',t(idx)); else, fprintf('Isolation verification did not pass.\n'); end
idx = find(spareInserted,1); if ~isempty(idx), fprintf('Spare insertion recorded at %.2f s\n',t(idx)); end
idx = find(reconVerified,1); if ~isempty(idx), fprintf('Reconfiguration verification recorded at %.2f s\n',t(idx)); else, fprintf('Reconfiguration verification did not pass.\n'); end
fprintf('Final pack voltage %.2f V | current %.2f A | shutdown=%d\n',packV(end),packI(end),any(shutdown));
disp('Saved EV_Battery_Test_01_Healthy_Results.csv and EV_Battery_Test_01_Healthy_Workspace.mat');
