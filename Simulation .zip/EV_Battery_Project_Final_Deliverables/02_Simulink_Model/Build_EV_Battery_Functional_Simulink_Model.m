%% Build_EV_Battery_Functional_Simulink_Model.m
% Creates a connected, signal-level Simulink model for the EV battery project.
% This is NOT a Simscape/electrochemical battery model and is not hardware validated.
% Run this script in MATLAB with Simulink installed. It creates:
% EV_Battery_Functional_Simulink_Model.slx

clear; clc;
model = 'EV_Battery_Functional_Simulink_Model';
if bdIsLoaded(model), close_system(model,0); end
if exist([model '.slx'],'file'), delete([model '.slx']); end
new_system(model); open_system(model);
set_param(model,'StopTime','80','Solver','FixedStepDiscrete','FixedStep','0.05');

% Helper for creating blocks at predictable positions.
add_block('simulink/Sources/Step',[model '/Fault_Injection'], ...
    'Time','15','Before','0','After','1','Position',[35 70 85 100]);
add_block('simulink/Sources/Constant',[model '/Nominal_M5_Voltage'], ...
    'Value','3.7','Position',[35 155 85 185]);
add_block('simulink/Sources/Constant',[model '/Faulted_M5_Voltage'], ...
    'Value','2.7','Position',[35 220 85 250]);
add_block('simulink/Signal Routing/Switch',[model '/M5_Fault_Voltage_Switch'], ...
    'Criteria','u2 >= Threshold','Threshold','0.5','Position',[150 145 205 240]);
add_block('simulink/Sources/Step',[model '/M5_Temperature'], ...
    'Time','15','Before','25','After','56.3','Position',[35 320 85 350]);
add_block('simulink/Sources/Constant',[model '/Low_Voltage_Threshold'], ...
    'Value','3.0','Position',[230 270 280 300]);
add_block('simulink/Math Operations/Relational Operator',[model '/Low_Voltage_Detector'], ...
    'Operator','<=','Position',[315 185 365 225]);
add_block('simulink/Sources/Constant',[model '/Thermal_Threshold'], ...
    'Value','55','Position',[230 345 280 375]);
add_block('simulink/Math Operations/Relational Operator',[model '/Thermal_Fault_Detector'], ...
    'Operator','>=','Position',[315 315 365 355]);
add_block('simulink/Logic and Bit Operations/Logical Operator',[model '/Fault_Detected_OR'], ...
    'Operator','OR','Inputs','2','Position',[420 235 465 295]);

% Three spare module nominal voltages. Compatibility is a demo setting.
add_block('simulink/Sources/Constant',[model '/Spare_1_Voltage'], ...
    'Value','3.7','Position',[35 430 85 460]);
add_block('simulink/Sources/Constant',[model '/Spare_2_Voltage'], ...
    'Value','3.6','Position',[35 475 85 505]);
add_block('simulink/Sources/Constant',[model '/Spare_3_Voltage'], ...
    'Value','3.5','Position',[35 520 85 550]);
add_block('simulink/Sources/Constant',[model '/Spare_Compatible'], ...
    'Value','1','Position',[230 435 280 465]);
add_block('simulink/Logic and Bit Operations/Logical Operator',[model '/Recovery_Allowed'], ...
    'Operator','AND','Inputs','2','Position',[420 400 465 455]);
add_block('simulink/Signal Routing/Switch',[model '/M5_Spare_Bypass_Switch'], ...
    'Criteria','u2 >= Threshold','Threshold','0.5','Position',[520 185 575 285]);

% Ten main modules are represented as nine healthy modules plus explicit M5.
add_block('simulink/Sources/Constant',[model '/Other_9_Main_Modules_Total_V'], ...
    'Value','33.3','Position',[520 80 585 110]);
add_block('simulink/Math Operations/Sum',[model '/Pack_Voltage_Sum'], ...
    'Inputs','++','Position',[640 170 675 225]);
add_block('simulink/Sources/Constant',[model '/Zero_Voltage'], ...
    'Value','0','Position',[640 300 685 330]);
add_block('simulink/Logic and Bit Operations/Logical Operator',[model '/Spare_Not_Compatible'], ...
    'Operator','NOT','Position',[315 435 360 470]);
add_block('simulink/Logic and Bit Operations/Logical Operator',[model '/Recovery_Failure'], ...
    'Operator','AND','Inputs','2','Position',[420 485 465 535]);
add_block('simulink/Sources/Constant',[model '/Critical_Temperature_Threshold'], ...
    'Value','60','Position',[230 580 280 610]);
add_block('simulink/Math Operations/Relational Operator',[model '/Critical_Thermal_Shutdown'], ...
    'Operator','>=','Position',[315 565 365 605]);
add_block('simulink/Logic and Bit Operations/Logical Operator',[model '/Shutdown_OR'], ...
    'Operator','OR','Inputs','2','Position',[520 465 565 525]);
add_block('simulink/Signal Routing/Switch',[model '/Pack_Output_Shutdown_Switch'], ...
    'Criteria','u2 >= Threshold','Threshold','0.5','Position',[735 175 790 275]);

% Outputs / monitoring
add_block('simulink/Sinks/Scope',[model '/Pack_Voltage_Scope'], ...
    'Position',[880 170 915 205]);
add_block('simulink/Sinks/Scope',[model '/Fault_Status_Scope'], ...
    'Position',[520 335 555 370]);
add_block('simulink/Sinks/Scope',[model '/Temperature_Scope'], ...
    'Position',[420 625 455 660]);
add_block('simulink/Sinks/Display',[model '/Pack_Voltage_Display'], ...
    'Position',[960 170 1030 205]);
add_block('simulink/Sinks/Display',[model '/Shutdown_Status_Display'], ...
    'Position',[735 390 805 425]);
add_block('simulink/Sinks/Display',[model '/Fault_Status_Display'], ...
    'Position',[520 385 590 420]);

% Workspace logging for repeatable automated checks (timeseries format).
add_block('simulink/Sinks/To Workspace',[model '/Log_Pack_Voltage'], ...
    'VariableName','pack_voltage_log','SaveFormat','Timeseries','Position',[960 230 1045 260]);
add_block('simulink/Sinks/To Workspace',[model '/Log_Fault_Status'], ...
    'VariableName','fault_status_log','SaveFormat','Timeseries','Position',[610 335 695 365]);
add_block('simulink/Sinks/To Workspace',[model '/Log_Shutdown_Status'], ...
    'VariableName','shutdown_status_log','SaveFormat','Timeseries','Position',[835 390 920 420]);
add_block('simulink/Sinks/To Workspace',[model '/Log_M5_Voltage'], ...
    'VariableName','m5_voltage_log','SaveFormat','Timeseries','Position',[230 150 315 180]);
add_block('simulink/Sinks/To Workspace',[model '/Log_M5_Temperature'], ...
    'VariableName','m5_temperature_log','SaveFormat','Timeseries','Position',[490 625 575 655]);

% Wiring: inject fault -> M5 voltage drop and temperature rise.
add_line(model,'Nominal_M5_Voltage/1','M5_Fault_Voltage_Switch/1','autorouting','on');
add_line(model,'Fault_Injection/1','M5_Fault_Voltage_Switch/2','autorouting','on');
add_line(model,'Faulted_M5_Voltage/1','M5_Fault_Voltage_Switch/3','autorouting','on');
add_line(model,'M5_Fault_Voltage_Switch/1','Low_Voltage_Detector/1','autorouting','on');
add_line(model,'Low_Voltage_Threshold/1','Low_Voltage_Detector/2','autorouting','on');
add_line(model,'M5_Temperature/1','Thermal_Fault_Detector/1','autorouting','on');
add_line(model,'Thermal_Threshold/1','Thermal_Fault_Detector/2','autorouting','on');
add_line(model,'Low_Voltage_Detector/1','Fault_Detected_OR/1','autorouting','on');
add_line(model,'Thermal_Fault_Detector/1','Fault_Detected_OR/2','autorouting','on');
add_line(model,'Fault_Detected_OR/1','Recovery_Allowed/1','autorouting','on');
add_line(model,'Spare_Compatible/1','Recovery_Allowed/2','autorouting','on');

% If recovery is allowed, insert spare 1 (3.7 V); otherwise retain faulty M5 voltage.
add_line(model,'Spare_1_Voltage/1','M5_Spare_Bypass_Switch/1','autorouting','on');
add_line(model,'Recovery_Allowed/1','M5_Spare_Bypass_Switch/2','autorouting','on');
add_line(model,'M5_Fault_Voltage_Switch/1','M5_Spare_Bypass_Switch/3','autorouting','on');
add_line(model,'Other_9_Main_Modules_Total_V/1','Pack_Voltage_Sum/1','autorouting','on');
add_line(model,'M5_Spare_Bypass_Switch/1','Pack_Voltage_Sum/2','autorouting','on');

% Shutdown if a detected fault cannot be recovered, or temperature reaches 60 C.
add_line(model,'Spare_Compatible/1','Spare_Not_Compatible/1','autorouting','on');
add_line(model,'Fault_Detected_OR/1','Recovery_Failure/1','autorouting','on');
add_line(model,'Spare_Not_Compatible/1','Recovery_Failure/2','autorouting','on');
add_line(model,'M5_Temperature/1','Critical_Thermal_Shutdown/1','autorouting','on');
add_line(model,'Critical_Temperature_Threshold/1','Critical_Thermal_Shutdown/2','autorouting','on');
add_line(model,'Recovery_Failure/1','Shutdown_OR/1','autorouting','on');
add_line(model,'Critical_Thermal_Shutdown/1','Shutdown_OR/2','autorouting','on');
add_line(model,'Pack_Voltage_Sum/1','Pack_Output_Shutdown_Switch/1','autorouting','on');
add_line(model,'Shutdown_OR/1','Pack_Output_Shutdown_Switch/2','autorouting','on');
add_line(model,'Zero_Voltage/1','Pack_Output_Shutdown_Switch/3','autorouting','on');
add_line(model,'Pack_Output_Shutdown_Switch/1','Pack_Voltage_Scope/1','autorouting','on');
add_line(model,'Pack_Output_Shutdown_Switch/1','Pack_Voltage_Display/1','autorouting','on');
add_line(model,'Fault_Detected_OR/1','Fault_Status_Scope/1','autorouting','on');
add_line(model,'Fault_Detected_OR/1','Fault_Status_Display/1','autorouting','on');
add_line(model,'M5_Temperature/1','Temperature_Scope/1','autorouting','on');
add_line(model,'Shutdown_OR/1','Shutdown_Status_Display/1','autorouting','on');
add_line(model,'Pack_Output_Shutdown_Switch/1','Log_Pack_Voltage/1','autorouting','on');
add_line(model,'Fault_Detected_OR/1','Log_Fault_Status/1','autorouting','on');
add_line(model,'Shutdown_OR/1','Log_Shutdown_Status/1','autorouting','on');
add_line(model,'M5_Fault_Voltage_Switch/1','Log_M5_Voltage/1','autorouting','on');
add_line(model,'M5_Temperature/1','Log_M5_Temperature/1','autorouting','on');

% Descriptive annotations
Simulink.Annotation(model, sprintf(['FUNCTIONAL SIGNAL-LEVEL EV BATTERY MODEL\n' ...
 '10 main modules: 9 healthy modules aggregated (33.3 V) + monitored M5.\n' ...
 '3 spare modules are represented by 3.7 V, 3.6 V and 3.5 V signals; demo selects spare 1.\n' ...
 'Fault injection at 15 s causes M5 voltage drop to 2.7 V and temperature to 56.3 C.\n' ...
 'Rule-based detection, spare compatibility, reconfiguration and safe shutdown are signal-level only.\n' ...
 'Not a Simscape electrical circuit, trained AI model, electrochemical model, or hardware validation.']));
set_param(model,'ZoomFactor','FitSystem');
save_system(model,[model '.slx']);
fprintf('Created %s.slx\n',model);
fprintf('Run the model for 80 s. Default: compatible spare, expected pack voltage returns to 37 V after reconfiguration.\n');
